export const homeObjOne={
    classNumber : "9",
    classInText: "class IX"
}

export const homeObjTwo={
    classNumber : "10",
    classInText: "class X"
}

export const homeObjThree={
    classNumber : "11",
    classInText: "class XI"
}

export const homeObjFour={
    classNumber : "12",
    classInText: "class XII"
}

export const homeObjFive={
    classNumber : "1-8",
    classInText: "class 1-8"
}

export const homeObjSix={
    classNumber : "IIT",
    classInText: "IIT JEE"
}

export const homeObjSeven={
    classNumber : "NEET",
    classInText: "NEET"
}

export const homeObjEight={
    classNumber : "ICSE",
    classInText: "ICSE"
}

export const homeObjNine={
    classNumber : "Govt. Exam",
    classInText: "GOVT"
}


export const homeObjTen={
    classNumber : "ENGG.",
    classInText: "ENGG"
}