export const NovelOne ={
    bookName:'Zero to one Notes',
    authorName:'Peter Thiel',
    price :275,
    originalPrice:550,
    img:'https://images-na.ssl-images-amazon.com/images/I/51z7mZZKRgL._SX317_BO1,204,203,200_.jpg',
    alt:'download'
}

export const NovelTwo ={
    bookName:'Harry Potter & The cursed Child',
    authorName:'J k Rowling',
    price :449,
    originalPrice:899,
    img:'https://images-eu.ssl-images-amazon.com/images/I/51oGcYakXEL._SY264_BO1,204,203,200_QL40_FMwebp_.jpg',
    alt:'harry potter'
}

export const NovelThree ={
    bookName:'Dollar Bahu',
    authorName:'Sudha Murty',
    price :150,
    originalPrice:250,
    img:'https://images-eu.ssl-images-amazon.com/images/I/41kyKfkReiL._SY264_BO1,204,203,200_QL40_FMwebp_.jpg',
    alt:'Bahu'
}

export const NovelFour ={
    bookName:'Will you still love me?',
    authorName:'Ravinder Singh',
    price :139,
    originalPrice:199,
    img:'https://m.media-amazon.com/images/I/81dw3K+R5-S._AC_UY327_FMwebp_QL65_.jpg',
    alt:'Ravinder Singh'
}